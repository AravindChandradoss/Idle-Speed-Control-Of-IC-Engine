%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Powertrain Control - ECE 5554
%
% Model of I.C. engine dynamics for idle speed control.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load engine geometric parameters and constant inputs

Vd = 2.4e-3;   % Displacement (m^3)
Z = 4;         % Number of Cylinders
Vm = 5.8e-3;   % Intake Manifold Volume (m^3)
J = 0.0789;    % Mass moment of inertia

p_amb = 1.0121*1e5;
T_amb = 302;
R=288;
gam = 1.35;

P0 = 26431;   % Initial MAP
N0 = 828;     % Initial RPM

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model parameters (from steady-state calibration)

a = [1.69e-07,-1.136e-06,6.89e-06];  % Throttle
si = 0.812;   yi = 0.0633;           % Volumetric efficiency
P_IMEP = [0.0220,-1.1649];           % IMEP
par_sp = [-0.0017 -0.0277 1.36];     % Spark timing effect
par_fr = [7.4198e-7 -4.989e-4 11.3]; % Friction

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run simulation
T_end = 20;
[T,X,Y] = sim('engine_model_idle',[T_end]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Example of Plotting Utility

% Plots Load Torque
figure('color',[1 1 1]);                                                                                            
h1=plot(T,Y(:,3));
set(h1,'color','b','linewidth',2);
hold on
grid on
box on
ylabel('Load Torque [Nm]');     
xlabel('Time [s]');
title('Engine Idle Speed Dynamics');
set(gca,'ylim',[0 30],'xlim',[0 T_end],'xtick',[0:2:T_end]);

% Plots Engine Speed
figure('color',[1 1 1]);                                                                                            
h1=plot(T,Y(:,6));
set(h1,'color','b','linewidth',2);
hold on
grid on
box on
ylabel('Engine Speed [r/min]');
xlabel('Time [s]');
title('Engine Idle Speed Dynamics');
set(gca,'ylim',[0 2000],'xlim',[0 T_end],'xtick',[0:2:T_end]);


% Plots MAP
figure('color',[1 1 1]);                                                                                            
h1=plot(T,Y(:,4)/1000);
set(h1,'color','b','linewidth',2);
hold on
grid on
box on
ylabel('MAP [kPa]');
xlabel('Time [s]');
title('Engine Idle Speed Dynamics');
%set(gca,'ylim',[0 2000],'xlim',[0 T_end],'xtick',[0:2:T_end]);


% Plots Indi Torque
figure('color',[1 1 1]);                                                                                            
h1=plot(T,Y(:,5));
set(h1,'color','b','linewidth',2);
hold on
grid on
box on
ylabel('Indi Torque [Nm]');
xlabel('Time [s]');
title('Engine Idle Speed Dynamics');
%set(gca,'ylim',[0 2000],'xlim',[0 T_end],'xtick',[0:2:T_end]);

