e_tor= [0
5
10
15
20]
map= [22.23
24.32
26.43
28.55
30.68
]
i_tor= [11.62
16.48
21.40
26.34
31.30
]
rpm=[1070
934.7
828.9
744.2
674.9
]
figure(1)
subplot(3,1,1)
plot(e_tor,rpm)
ylabel('Engine speed [rpm]');
xlabel('External Torque [Nm]');
title('Ext Torque Vs Speed');
subplot(3,1,2)
plot(e_tor,map)
ylabel('MAP [kPa]');
xlabel('External Torque [Nm]');
title('Ext Torque Vs MAP');
subplot(3,1,3)
plot(e_tor,i_tor)
ylabel('Indicated Torque [Nm]');
xlabel('External Torque [Nm]');
title('External Torque Vs Indi Torque');
suptitle('For fixed throttle angle (10�) and spark advance (25� bTDC)');