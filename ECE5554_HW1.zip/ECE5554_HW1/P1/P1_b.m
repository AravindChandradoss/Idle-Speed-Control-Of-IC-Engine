tor_angle= [7
8
10
12
14
16
]
map= [ 26.40
26.37
26.43
26.57
26.84
27.28
]
i_tor= [21.36
21.26
21.40
21.73
22.35
23.37
]
rpm=[489 
576.6
828.9
1164
1573
2040
]
figure(1)
subplot(3,1,1)
plot(tor_angle,rpm)
ylabel('Engine speed [rpm]');
xlabel('Throttle angle [Degree]');
title('Throttle angle [Degree] Vs Speed');
subplot(3,1,2)
plot(tor_angle,map)
ylabel('MAP [kPa]');
xlabel('Throttle angle [Degree]');
title('Throttle angle Vs MAP');
subplot(3,1,3)
plot(tor_angle,i_tor)
ylabel('Indicated Torque [Nm]');
xlabel('Throttle angle [Degree]');
title('Throttle angle Vs Indicated Torque');
suptitle('For fixed External Torque (10Nm) and spark advance (25� bTDC)');