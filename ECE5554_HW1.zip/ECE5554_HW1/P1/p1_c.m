Sprk_ad= [5
10
15
20
25
30
]
map= [23.53
23.48
23.81
24.64
26.43
30.94
]
i_tor= [21.53
21.53
21.51
21.47
21.40
21.30
]
rpm=[981.8
984.7
964.6
917.1
828.9
667.5
]
figure(1)
subplot(3,1,1)
plot(Sprk_ad,rpm)
ylabel('Engine speed [rpm]');
xlabel('Spark Advance [Degree]');
title('Spark Advance Vs Speed');
set(gca, 'XDir','reverse')
subplot(3,1,2)
plot(Sprk_ad,map)
ylabel('MAP [kPa]');
xlabel('Spark Advance [Degree]');
title('ESpark Advance Vs MAP');
set(gca, 'XDir','reverse')
subplot(3,1,3)
plot(Sprk_ad,i_tor)
ylabel('Indicated Torque [Nm]');
xlabel('Spark Advance [Degree]');
title('Spark Advance Vs Indi Torque');
set(gca, 'XDir','reverse')
suptitle('For fixed throttle angle (10�) and Ext Torque (10Nm)');