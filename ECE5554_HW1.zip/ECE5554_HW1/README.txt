
To run each file.
Make sure to run the file at right directory.
=====================================================================================================
-Go to folder, which you want to run.
-Make sure to close all other file/simulink/program to avoid over-shadow of files.
-Open and run the file with name "HW1_Problem*_main"
-Make sure close the opened file/sumulink/program to avoid chances of getting over-shadows afterwords.
=====================================================================================================

The codes were working fine in my Laptop. 
Feel free to ping me! if you face any issues. 

  