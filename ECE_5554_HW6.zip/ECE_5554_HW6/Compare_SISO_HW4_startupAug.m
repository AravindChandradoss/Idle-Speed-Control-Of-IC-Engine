%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Powertrain Control 
%
% Model of I.C. engine dynamics for idle speed control.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%close all
clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load engine geometric parameters and constant inputs

Vd = 2.4e-3;   % Displacement (m^3)
Z = 4;         % Number of Cylinders
Vm = 5.8e-3;   % Intake Manifold Volume (m^3)
J = 0.0789;    % Mass moment of inertia

p_amb = 1.0121*1e5;
T_amb = 302;
R=288;
gam = 1.35;

P0 = 26431;   % Initial MAP
N0 = 828;     % Initial RPM

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model parameters (from steady-state calibration)

a = [1.69e-07,-1.136e-06,6.89e-06];  % Throttle
si = 0.812;   yi = 0.0633;           % Volumetric efficiency
P_IMEP = [0.0220,-1.1649];           % IMEP
par_sp = [-0.0017 -0.0277 1.36];     % Spark timing effect
par_fr = [7.4198e-7 -4.989e-4 11.3]; % Friction
par_IMEP0 = [1.2323e-4 2.1256];      % Base IMEP model

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Conversion to Crank Angle Domain

% Coefficients for crank-angle based model
Kthr = p_amb/sqrt(R*T_amb)*sqrt(gam)*sqrt((2/(gam+1))^((gam+1)/(gam-1)));
Kp1 = R*T_amb/Vm;
Kp2 = si*Vd/(4*pi*Vm);
Kp3 = yi*Vd/(4*pi*Vm);
KT = 1e5*Vd/(4*pi);
Kfr1 = (30/pi)^2 * par_fr(1);
Kfr2 = (30/pi) * par_fr(2);
Kfr3 = par_fr(3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate Equilibrium Condition (p_0 T_0 w_0)

setp(1) = 9.81; % Throttle Position
setp(2) = -25;  % Spark Timing
setp(3) = 10;   % Load Torque
X0 = [26424 21.3765773202354 83.9019428270409]; % Equilibrium Conditions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearization

% Coefficients for linearized model as shown in lecture
K1 = Kp1*Kthr*(2*a(1)*setp(1)+a(2));
K2 = Kp1*Kthr*(a(1)*setp(1)^2 + a(2)*setp(1) + a(3));
K3 = Kp2;
Kp = KT*par_IMEP0(1)*(par_sp(1)*setp(2)^2 + par_sp(2)*setp(2) + par_sp(3));    % Pressure multiplier
%Kt = KT*(par_IMEP0(1)*X0(1) - par_IMEP0(2)) * (par_sp(1)*setp(2) + par_sp(2)); 
Kf = 2*Kfr1*X0(3)^2 + Kfr2*X0(3);
Ktheta = KT*(par_IMEP0(1)*X0(1)-par_IMEP0(2))*(2*par_sp(1)*setp(2)+par_sp(2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Discretization (solved in Homework 2)

Tau_d = pi/3;   % Discrete sampling time (1 order of engine firing)
tau=Tau_d;
w=X0(3);
Ndel = 3;       % Number of integer delays (in combustion model)

% Coefficients of Discrete Model
CT1 = 1+0.5*Tau_d*K3;
CT2 = -1+0.5*Tau_d*K3;
CT3 = 0.5*Tau_d*K2/X0(3)^2;
CT4 = 0.5*Tau_d*K1/X0(3);

CT5 = 1+0.5*Tau_d*Kf/(J*X0(3)^2);
CT6 = -1+0.5*Tau_d*Kf/(J*X0(3)^2);
CT7 = 0.5*Tau_d/J/X0(3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matrices for the state-space representation

M = 1/sqrt(Tau_d) * [-CT1, -CT3; 0,  -CT5];
N = 1/sqrt(Tau_d) * [ CT4, 0;    0,  CT7];
O = 1/sqrt(Tau_d) * [ CT2, CT3;  0,  CT6];
P = 1/sqrt(Tau_d) * [-CT4, 0;    0, -CT7];

Q = -O*M^(-1)*N+P;
R = O*M^(-1);
S = M^(-1);
U = -(M^(-1)*N);

Phi = [ R(1,1), R(1,2), 0, 0, Q(1,2)*Kp, 0;...
        R(2,1), R(2,2), 0, 0, Q(2,2)*Kp, 0;...
        S(1,1), S(1,2), 0, 0, U(1,2)*Kp, 0;...
             0,      0, 1, 0,         0, 0;...
             0,      0, 0, 1,         0, 0;
        S(2,1), S(2,2), 0, 0, U(2,2)*Kp, 1];   

Gamma =  [Q(1,1); Q(2,1); U(1,1); 0; 0; 0];

H     =  [S(2,1), S(2,2), 0, 0, U(2,2)*Kp, 0];       

D     =  [U(2,1)];

[A,B] = ss2tf(Phi,Gamma,H,D);
Csys=tf(A,B);
Cont = [Gamma Phi*Gamma Phi^2*Gamma Phi^3*Gamma Phi^4*Gamma];
rank(Cont);
p = [0.9+0.2i 0.9-0.2i 0.7+0.1i 0.7-0.1i 0.92 0.95];
%p = [0.92+0.2i 0.92-0.2i 0.95+0.1i 0.95-0.1i -0.01 .8];
k=place(Phi,Gamma,p);
LQ=[1 0 0 0 0 0;
    0 10000 0 0 0 0;
    0 0 10 0 0 0;
    0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 10000];
LQ2 = [9999999];
[K,S1,E1]=dlqr(Phi,Gamma,LQ,LQ2);
k=K

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%Simulation
sim('SISO_DTmodelAug');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plots
figure(1);
subplot(3,1,1);
stairs(theta,(dw+w)*(60/(2*pi)),'LineWidth',1.5);
subplot(3,1,2);
stairs(theta,(dalpha+setp(1)),'LineWidth',1.5);
subplot(3,1,3);
stairs(theta,ip,'LineWidth',1.5);

k=place(Phi,Gamma,E1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%Simulation
sim('SISO_DTmodelAug');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plots
figure(1);
subplot(3,1,1);
hold on
stairs(theta,(dw+w)*(60/(2*pi)),'y--','LineWidth',1.5);
xlabel('Crank angel (rad/sec)')
ylabel('Speed (RPM)')
title('Speed Vs Crank angle')
xlim([0 1600])
ylim([500 1000])
legend('LQR','PolePlacement')
grid on
subplot(3,1,2);
hold on
stairs(theta,(dalpha+setp(1)),'y--','LineWidth',1.5);
xlabel('Crank angel (rad/sec)')
ylabel('Throttle angle (Degree)')
title('Control Action')
ylim([5 15]);
xlim([0 1600])
legend('LQR','PolePlacement')
grid on
subplot(3,1,3);
hold on
stairs(theta,ip,'y--','LineWidth',1.5);
xlabel('Crank angel (rad/sec)')
ylabel('Load Torque (Nm)')
title('Disturbance')
ylim([-1 11]);
xlim([0 1600])
legend('LQR','PolePlacement')
grid on
suptitle('Closedloop Response for load torque disturbance')





