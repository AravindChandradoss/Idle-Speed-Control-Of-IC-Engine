clear all

% Continuous time model, from Newton's second law:

F = [0 1; 0 -0.4];
G = [0; 2];
H= [0 1];
Hp=[1 0];

% H=[0 0 1 0; % For velocity sensing only
%    0 0 0 1];
% 
% Hp=[1 0 0 0; % For position sensing only
%    0 1 0 0];

J=[0];
%%% Convert continuous time system to discrete time using sampling/ZOH

T=0.1; % Sampling period

[Phi,Gamma]=c2d(F,G,T); % Uses ZOH, gives DT representation of
                       % Phi, Gamma, H, J

% Pick weighting matrics for state, input, and state-input pair
%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q1=[1 0;
    0 1];

Q2=[5];

Q3=[0;
    0;];

% Compute optimal gain, K, and Riccati solution S, and closed-loop
% eigenvalues E

[K,S,E]=dlqr(Phi,Gamma,Q1,Q2,Q3); % Computes gain K, u=-Kx, for LQR
                       % (assumes full state feedback)

% Print out closed-loop root locations
K
E

% Simulate the closed-loop system
T=0.1;
SYS=ss((Phi-Gamma*K),Gamma,H,J,T);
Tfinal=10;

[Y,T,X]=initial(SYS,[-11 -22]',Tfinal);

% Compute the input to the robot from the state trajectory

for i=1:length(T)
    
    U(i,:)=-K*X(i,:)';

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q1=[1 0;
    0 1];

Q2=[10];

Q3=[0;
    0;];

% Compute optimal gain, K, and Riccati solution S, and closed-loop
% eigenvalues E

[K,S,E]=dlqr(Phi,Gamma,Q1,Q2,Q3); % Computes gain K, u=-Kx, for LQR
                       % (assumes full state feedback)

% Print out closed-loop root locations
K
E

% Simulate the closed-loop system
T=0.1;
SYS=ss((Phi-Gamma*K),Gamma,H,J,T);
Tfinal=10;

[Y,T,X]=initial(SYS,[-11 -22]',Tfinal);

% Compute the input to the robot from the state trajectory

for i=1:length(T)
    
    U2(i,:)=-K*X(i,:)';

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q1=[1 0;
    0 1];

Q2=[50];

Q3=[0;
    0;];

% Compute optimal gain, K, and Riccati solution S, and closed-loop
% eigenvalues E

[K,S,E]=dlqr(Phi,Gamma,Q1,Q2,Q3); % Computes gain K, u=-Kx, for LQR
                       % (assumes full state feedback)

% Print out closed-loop root locations
K
E

% Simulate the closed-loop system
T=0.1;
SYS=ss((Phi-Gamma*K),Gamma,H,J,T);
Tfinal=10;

[Y,T,X]=initial(SYS,[-11 -22]',Tfinal);

% Compute the input to the robot from the state trajectory

for i=1:length(T)
    
    U3(i,:)=-K*X(i,:)';

end

% Plot the data from the simulation

figure(1)
clf
%subplot(3,1,1)
plot(T,U,'b')
grid on
% The states
hold on
%subplot(3,1,2)
plot(T,U2,'r')
grid on
hold on
%subplot(3,1,3)
plot(T,U3,'y')
grid on
xlabel('Time')
ylabel('Magnitute')
legend('Controller output=5','Controller output=10','Controller output=50')
title('Comparison w.r.t Q2 with Q1=I')